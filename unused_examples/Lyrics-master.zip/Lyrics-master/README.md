Lyrics
======

A-Z lyrics scraping

This is a simple Python library that can scrape song and lyric information for a given artist.

I've used this library for posts on my blog:

https://brianchesley.com/blog
